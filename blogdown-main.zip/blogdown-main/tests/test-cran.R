library(testit)
test_pkg('blogdown', 'test-cran')
